//: Alien.java
// A serializable class
import java.io.*;

public class Alien implements Serializable {
} ///:~