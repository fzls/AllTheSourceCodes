//: Destination.java
package c07.innerscopes;

interface Destination {
  String readLabel();
} ///:~