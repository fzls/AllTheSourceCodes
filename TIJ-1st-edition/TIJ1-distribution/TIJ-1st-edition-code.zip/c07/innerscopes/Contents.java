//: Contents.java
package c07.innerscopes;

interface Contents {
  int value();
} ///:~