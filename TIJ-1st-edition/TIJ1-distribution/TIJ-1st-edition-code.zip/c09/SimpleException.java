//: SimpleException.java
class SimpleException extends Exception {
} ///:~